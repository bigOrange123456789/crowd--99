clc
addpath('src');
addpath('lib/jsonlab-master');

%Group.process_save('manA20_2.json',0.99,3);
Group.process_save('manA20.json',0.001,20);
%Group.process_save('manA20.json',0.01,20);
%Group.process_save('test2.json',0.5,4);
